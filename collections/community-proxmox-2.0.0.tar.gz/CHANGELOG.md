# Community Proxmox Collection Release Notes

**Topics**

- <a href="#v2-0-0">v2\.0\.0</a>
    - <a href="#release-summary">Release Summary</a>
    - <a href="#minor-changes">Minor Changes</a>
    - <a href="#breaking-changes--porting-guide">Breaking Changes / Porting Guide</a>
    - <a href="#bugfixes">Bugfixes</a>
    - <a href="#new-plugins">New Plugins</a>
        - <a href="#connection">Connection</a>
    - <a href="#new-modules">New Modules</a>
- <a href="#v1-6-0">v1\.6\.0</a>
    - <a href="#release-summary-1">Release Summary</a>
    - <a href="#major-changes">Major Changes</a>
    - <a href="#minor-changes-1">Minor Changes</a>
    - <a href="#deprecated-features">Deprecated Features</a>
    - <a href="#bugfixes-1">Bugfixes</a>
    - <a href="#new-modules-1">New Modules</a>
- <a href="#v1-5-0">v1\.5\.0</a>
    - <a href="#release-summary-2">Release Summary</a>
    - <a href="#minor-changes-2">Minor Changes</a>
    - <a href="#bugfixes-2">Bugfixes</a>
    - <a href="#new-modules-2">New Modules</a>
- <a href="#v1-4-0">v1\.4\.0</a>
    - <a href="#release-summary-3">Release Summary</a>
    - <a href="#minor-changes-3">Minor Changes</a>
    - <a href="#bugfixes-3">Bugfixes</a>
    - <a href="#new-modules-3">New Modules</a>
- <a href="#v1-3-0">v1\.3\.0</a>
    - <a href="#release-summary-4">Release Summary</a>
    - <a href="#minor-changes-4">Minor Changes</a>
    - <a href="#bugfixes-4">Bugfixes</a>
    - <a href="#new-modules-4">New Modules</a>
- <a href="#v1-2-0">v1\.2\.0</a>
    - <a href="#release-summary-5">Release Summary</a>
    - <a href="#minor-changes-5">Minor Changes</a>
    - <a href="#new-modules-5">New Modules</a>
- <a href="#v1-1-0">v1\.1\.0</a>
    - <a href="#release-summary-6">Release Summary</a>
    - <a href="#minor-changes-6">Minor Changes</a>
    - <a href="#bugfixes-5">Bugfixes</a>
    - <a href="#new-modules-6">New Modules</a>
- <a href="#v1-0-1">v1\.0\.1</a>
    - <a href="#release-summary-7">Release Summary</a>
    - <a href="#minor-changes-7">Minor Changes</a>
- <a href="#v1-0-0">v1\.0\.0</a>
    - <a href="#release-summary-8">Release Summary</a>
    - <a href="#minor-changes-8">Minor Changes</a>
    - <a href="#breaking-changes--porting-guide-1">Breaking Changes / Porting Guide</a>
    - <a href="#bugfixes-6">Bugfixes</a>
    - <a href="#new-modules-7">New Modules</a>
- <a href="#v0-1-0">v0\.1\.0</a>
    - <a href="#release-summary-9">Release Summary</a>

<a id="v2-0-0"></a>
## v2\.0\.0

<a id="release-summary"></a>
### Release Summary

This is the major release of the <code>community\.proxmox</code> collection\.
This changelog contains all changes to the modules and plugins in this collection
that have been made after the previous release\.

Please note that this version of the collection now requires proxmoxer 2\.3\.0 or higher\.

<a id="minor-changes"></a>
### Minor Changes

* proxmox \- add <code>destroy\_unreferenced\_disks</code> parameter \([https\://github\.com/ansible\-collections/community\.proxmox/pull/422](https\://github\.com/ansible\-collections/community\.proxmox/pull/422)\)\.
* proxmox \- add <code>totp</code> authentification support \([https\://github\.com/ansible\-collections/community\.proxmox/pull/265](https\://github\.com/ansible\-collections/community\.proxmox/pull/265)\)\.
* proxmox \- add a new helper <em class="title-reference">create\_proxmox\_module\(\)</em> which adds generic auth args and constraints\, and merges in the module\-specific args and options \([https\://github\.com/ansible\-collections/community\.proxmox/pull/289](https\://github\.com/ansible\-collections/community\.proxmox/pull/289)\)\.
* proxmox \- adds <code>cmode</code> parameter for supporting console modes \([https\://github\.com/ansible\-collections/community\.proxmox/pull/420](https\://github\.com/ansible\-collections/community\.proxmox/pull/420)  / issue [https\://github\.com/ansible\-collections/community\.proxmox/issues/65](https\://github\.com/ansible\-collections/community\.proxmox/issues/65)\)\.
* proxmox \- update <code>proxmoxer</code> required dependencies to <code>\>\=2\.3</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/265](https\://github\.com/ansible\-collections/community\.proxmox/pull/265)\)\.
* proxmox inventory \- add <code>templates</code> group to the inventory \([https\://github\.com/ansible\-collections/community\.proxmox/pull/399](https\://github\.com/ansible\-collections/community\.proxmox/pull/399)\)\.
* proxmox\_acme\_account \- set <code>no\_log</code> on sensitive value <code>eab\_kid</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/418](https\://github\.com/ansible\-collections/community\.proxmox/pull/418)\)\.
* proxmox\_kvm \- add <code>destroy\_unreferenced\_disks</code> parameter \([https\://github\.com/ansible\-collections/community\.proxmox/pull/422](https\://github\.com/ansible\-collections/community\.proxmox/pull/422)\)\.
* proxmox\_kvm \- add qemu parameter <code>spice\_enhancements</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/324](https\://github\.com/ansible\-collections/community\.proxmox/pull/324)\)\.
* proxmox\_kvm \- add qemu parameter <code>virtiofs</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/336](https\://github\.com/ansible\-collections/community\.proxmox/pull/336)\)\.
* proxmox\_node \- add alias <code>certificate\_file\_path</code> for <code>cert</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/331](https\://github\.com/ansible\-collections/community\.proxmox/pull/331)\)\.
* proxmox\_node \- add alias <code>node</code> for <code>node\_name</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/331](https\://github\.com/ansible\-collections/community\.proxmox/pull/331)\)\.
* proxmox\_node \- add alias <code>private\_key\_file\_path</code> for <code>key</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/331](https\://github\.com/ansible\-collections/community\.proxmox/pull/331)\)\.
* proxmox\_node \- add new parameter <code>certificate</code> to pass raw PEM encoded certificate \([https\://github\.com/ansible\-collections/community\.proxmox/pull/331](https\://github\.com/ansible\-collections/community\.proxmox/pull/331)\)\.
* proxmox\_node \- add new parameter <code>private\_key</code> to pass raw PEM encoded private key \([https\://github\.com/ansible\-collections/community\.proxmox/pull/331](https\://github\.com/ansible\-collections/community\.proxmox/pull/331)\)\.
* proxmox\_storage \- Add support for RBD \(RADOS Block Device\) storage \([https\://github\.com/ansible\-collections/community\.proxmox/issues/329](https\://github\.com/ansible\-collections/community\.proxmox/issues/329)\)\.
* proxmox\_storage \- add <code>preallocation</code> parameter on <code>cifs</code> storage backend \([https\://github\.com/ansible\-collections/community\.proxmox/pull/386](https\://github\.com/ansible\-collections/community\.proxmox/pull/386)\)\.
* proxmox\_storage \- add <code>preallocation</code> parameter on <code>nfs</code> storage backend \([https\://github\.com/ansible\-collections/community\.proxmox/pull/390](https\://github\.com/ansible\-collections/community\.proxmox/pull/390)\)\.
* proxmox\_storage \- add <code>snapshot\_as\_volume\_chain</code> parameter on <code>cifs</code> storage backend \([https\://github\.com/ansible\-collections/community\.proxmox/pull/387](https\://github\.com/ansible\-collections/community\.proxmox/pull/387)\)\.
* proxmox\_storage \- add alias <code>subdirectory</code> for <code>subdir</code> on cifs backend \([https\://github\.com/ansible\-collections/community\.proxmox/pull/388](https\://github\.com/ansible\-collections/community\.proxmox/pull/388)\)\.
* proxmox\_storage \- add support of <code>encryption\_key</code> on <code>pbs</code> storage backend \([https\://github\.com/ansible\-collections/community\.proxmox/pull/389](https\://github\.com/ansible\-collections/community\.proxmox/pull/389)\)\.
* proxmox\_storage \- enhanced error handling and parameters validation \([https\://github\.com/ansible\-collections/community\.proxmox/pull/305](https\://github\.com/ansible\-collections/community\.proxmox/pull/305)\)\.
* proxmox\_storage \- the parameter <code>state</code> now has a default value of <code>present</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/305](https\://github\.com/ansible\-collections/community\.proxmox/pull/305)\)\.
* proxmox\_storage \- when <code>state\=present</code> parameters <code>content</code> and <code>nodes</code> are now not required \([https\://github\.com/ansible\-collections/community\.proxmox/pull/315](https\://github\.com/ansible\-collections/community\.proxmox/pull/315)\)\.

<a id="breaking-changes--porting-guide"></a>
### Breaking Changes / Porting Guide

* proxmox\_pool\_member \- move <em class="title-reference">member</em> parameter to a <em class="title-reference">members</em> list to manage multiple pool members at once\. Add a new <em class="title-reference">exclusive</em> parameter to switch between full and incremental mode \([https\://github\.com/ansible\-collections/community\.proxmox/pull/373](https\://github\.com/ansible\-collections/community\.proxmox/pull/373) / issue [https\://github\.com/ansible\-collections/community\.proxmox/issues/320](https\://github\.com/ansible\-collections/community\.proxmox/issues/320)\)\.

<a id="bugfixes"></a>
### Bugfixes

* proxmox \- fix <code>tags</code> always being reported as changed on LXC container updates because the list value was compared against Proxmox\'s semicolon\-delimited string form \([https\://github\.com/ansible\-collections/community\.proxmox/pull/415](https\://github\.com/ansible\-collections/community\.proxmox/pull/415)\)\.
* proxmox modules \- fix calls to <code>get\_storages\(\)</code> to use the correct keyword argument \([https\://github\.com/ansible\-collections/community\.proxmox/pull/401](https\://github\.com/ansible\-collections/community\.proxmox/pull/401)\)\.
* proxmox\_cluster\_firewall \- error message for invalid log\_ratelimit\.rate parameter \([https\://github\.com/ansible\-collections/community\.proxmox/pull/340](https\://github\.com/ansible\-collections/community\.proxmox/pull/340)\)\.
* proxmox\_disk \- add support for efidisk and tpmstate disk bus types which previously caused module failure with \"Unsupported disk bus\" error \([https\://github\.com/ansible\-collections/community\.proxmox/pull/319](https\://github\.com/ansible\-collections/community\.proxmox/pull/319)\)\.
* proxmox\_firewall\_info \- add none guard on get\_ip\_sets to prevent crash with <code>\'NoneType\' object has no attribute \'ipset\'</code> when using <code>level\=group</code> \([https\://github\.com/ansible\-collections/community\.proxmox/issues/430](https\://github\.com/ansible\-collections/community\.proxmox/issues/430)\)\.
* proxmox\_pool \- member retrieval \([https\://github\.com/ansible\-collections/community\.proxmox/pull/412](https\://github\.com/ansible\-collections/community\.proxmox/pull/412)\)\.
* proxmox\_pool \- support nested pool \([https\://github\.com/ansible\-collections/community\.proxmox/pull/316](https\://github\.com/ansible\-collections/community\.proxmox/pull/316)\)\.
* proxmox\_pool\_member \- fix pool membership operations failing for nested pool IDs \([https\://github\.com/ansible\-collections/community\.proxmox/pull/428](https\://github\.com/ansible\-collections/community\.proxmox/pull/428)\)\.
* proxmox\_pool\_member \- fix pool membership update \([https\://github\.com/ansible\-collections/community\.proxmox/pull/428](https\://github\.com/ansible\-collections/community\.proxmox/pull/428)\)\.
* proxmox\_pool\_member \- fix usage of storage member \([https\://github\.com/ansible\-collections/community\.proxmox/pull/411](https\://github\.com/ansible\-collections/community\.proxmox/pull/411)\)\.
* proxmox\_pool\_member \- member retrieval \([https\://github\.com/ansible\-collections/community\.proxmox/pull/412](https\://github\.com/ansible\-collections/community\.proxmox/pull/412)\)\.
* proxmox\_snap \- fail the task when a given snapname does not exist instead of exiting \([https\://github\.com/ansible\-collections/community\.proxmox/pull/365](https\://github\.com/ansible\-collections/community\.proxmox/pull/365)\)\.
* proxmox\_storage \- backend <code>cephfs</code>\, <code>dir</code> and <code>zfspool</code> doesn\'t requires <code>content</code> parameter \([https\://github\.com/ansible\-collections/community\.proxmox/pull/315](https\://github\.com/ansible\-collections/community\.proxmox/pull/315)\)\.
* proxmox\_storage \- the parameter <code>client\_keyring</code> was ignored \([https\://github\.com/ansible\-collections/community\.proxmox/pull/305](https\://github\.com/ansible\-collections/community\.proxmox/pull/305)\)\.
* proxmox\_storage \- the parameter <code>fs\_name</code> was ignored \([https\://github\.com/ansible\-collections/community\.proxmox/pull/305](https\://github\.com/ansible\-collections/community\.proxmox/pull/305)\)\.
* proxmox\_storage \- the parameter <code>state</code> was optional and without default value \([https\://github\.com/ansible\-collections/community\.proxmox/pull/305](https\://github\.com/ansible\-collections/community\.proxmox/pull/305)\)\.

<a id="new-plugins"></a>
### New Plugins

<a id="connection"></a>
#### Connection

* community\.proxmox\.proxmox\_qemu\_api \- Connect to QEMU VMs via the Proxmox guest agent API\.

<a id="new-modules"></a>
### New Modules

* community\.proxmox\.proxmox\_acme\_account \- Manages an ACME account\.
* community\.proxmox\.proxmox\_acme\_account\_info \- Retrieves information about a specific ACME account\.
* community\.proxmox\.proxmox\_acme\_accounts\_info \- Retrieves the list of ACME accounts\.
* community\.proxmox\.proxmox\_acme\_certificate \- Manages ACME SSL certificates for Proxmox VE nodes\.
* community\.proxmox\.proxmox\_acme\_certificates\_info \- Retrieves the list of certificates on a Proxmox VE node\.
* community\.proxmox\.proxmox\_acme\_plugin\_dns \- Manage ACME DNS plugins on a Proxmox VE\.
* community\.proxmox\.proxmox\_acme\_plugin\_info \- Retrieves a single ACME plugin\.
* community\.proxmox\.proxmox\_acme\_plugins\_info \- Retrieves the list of ACME plugins\.
* community\.proxmox\.proxmox\_ceph\_pool \- Manage Ceph Pool\.
* community\.proxmox\.proxmox\_cluster\_firewall \- Cluster\-level firewall options management for Proxmox VE cluster\.
* community\.proxmox\.proxmox\_cluster\_ha\_rules\_info \- Retrieve Proxmox VE HA rules\.
* community\.proxmox\.proxmox\_domain \- Manage authentication realms\.
* community\.proxmox\.proxmox\_domain\_sync \- Sync realms\.
* community\.proxmox\.proxmox\_node\_firewall \- Node\-level firewall options management for Proxmox VE cluster\.
* community\.proxmox\.proxmox\_node\_firewall\_info \- Get node\-level firewall options for Proxmox VE cluster\.

<a id="v1-6-0"></a>
## v1\.6\.0

<a id="release-summary-1"></a>
### Release Summary

This is the minor release of the <code>community\.proxmox</code> collection\.
This changelog contains all changes to the modules and plugins in this collection
that have been made after the previous release\.

<a id="major-changes"></a>
### Major Changes

* proxmox \- Add ca\_path option to specify a ca\-certificate for tls validation \([https\://github\.com/ansible\-collections/community\.proxmox/pull/256](https\://github\.com/ansible\-collections/community\.proxmox/pull/256)\)\.

<a id="minor-changes-1"></a>
### Minor Changes

* inventory plugin \- add want\_post\_filtering\_facts to delay fact gathering until filtering has completed \([https\://github\.com/ansible\-collections/community\.proxmox/pull/261](https\://github\.com/ansible\-collections/community\.proxmox/pull/261)\)\.
* proxmox \- Add api\_timeout option for all modules \([https\://github\.com/ansible\-collections/community\.proxmox/pull/253](https\://github\.com/ansible\-collections/community\.proxmox/pull/253)\)\.
* proxmox \- set <code>state</code> as not <code>required</code> and set default value <code>present</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/292](https\://github\.com/ansible\-collections/community\.proxmox/pull/292)\)\.
* proxmox\_role \- add role\'s privs on the return data \([https\://github\.com/ansible\-collections/community\.proxmox/pull/283](https\://github\.com/ansible\-collections/community\.proxmox/pull/283)\)\.
* proxmox\_storage \- Add support for ZFS thin\-provisioning \([https\://github\.com/ansible\-collections/community\.proxmox/pull/265](https\://github\.com/ansible\-collections/community\.proxmox/pull/265)\)\.
* proxmox\_storage \- Add the option namespace for PBS storage \([https\://github\.com/ansible\-collections/community\.proxmox/pull/282](https\://github\.com/ansible\-collections/community\.proxmox/pull/282)\)
* proxmox\_storage \- refactor the validation of storage options \([https\://github\.com/ansible\-collections/community\.proxmox/pull/266](https\://github\.com/ansible\-collections/community\.proxmox/pull/266)\)\.
* proxmox\_storage\_contents\_info \- Add support for content type <code>import</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/260](https\://github\.com/ansible\-collections/community\.proxmox/pull/260)\)\.
* proxmox\_zone\, proxmox\_vnet\, proxmox\_subnet \- make sdn modules compatible with pve8 \([https\://github\.com/ansible\-collections/community\.proxmox/pull/254](https\://github\.com/ansible\-collections/community\.proxmox/pull/254)\)\.

<a id="deprecated-features"></a>
### Deprecated Features

* proxmox \- Certificate verification default changes from <code>false</code> to <code>true</code> with version 2\.0\.0 \([https\://github\.com/ansible\-collections/community\.proxmox/pull/256](https\://github\.com/ansible\-collections/community\.proxmox/pull/256)\)\.

<a id="bugfixes-1"></a>
### Bugfixes

* proxmox\_cluster \- make cluster join idempotent \([https\://github\.com/ansible\-collections/community\.proxmox/pull/244](https\://github\.com/ansible\-collections/community\.proxmox/pull/244)\)\.
* proxmox\_disk \- make none iso disk idempotent \([https\://github\.com/ansible\-collections/community\.proxmox/pull/288](https\://github\.com/ansible\-collections/community\.proxmox/pull/288)\)\.
* proxmox\_firewall \- Enable ipsets on vm level and fix bugs regarding the cidr notation the proxmox api expects \([https\://github\.com/ansible\-collections/community\.proxmox/pull/248](https\://github\.com/ansible\-collections/community\.proxmox/pull/248)\)\.
* proxmox\_role \- when privs is omitted\, keep existing role privileges unchanged instead of treating it as no privileges \([https\://github\.com/ansible\-collections/community\.proxmox/pull/284](https\://github\.com/ansible\-collections/community\.proxmox/pull/284)\)\.

<a id="new-modules-1"></a>
### New Modules

* community\.proxmox\.proxmox\_role \- Role management for Proxmox VE cluster\.

<a id="v1-5-0"></a>
## v1\.5\.0

<a id="release-summary-2"></a>
### Release Summary

This is the minor release of the <code>community\.proxmox</code> collection\.
This changelog contains all changes to the modules and plugins in this collection
that have been made after the previous release\.

<a id="minor-changes-2"></a>
### Minor Changes

* inventory plugin\, plugin\_utils \- replace deprecated <code>ansible\.module\_utils\.common\.\_collections\_compat</code> imports with <code>collections\.abc</code> from the Python standard library \([https\://github\.com/ansible\-collections/community\.proxmox/issues/241](https\://github\.com/ansible\-collections/community\.proxmox/issues/241)\)\.
* proxmox \- change disk size units to GiB \([https\://github\.com/ansible\-collections/community\.proxmox/pull/236](https\://github\.com/ansible\-collections/community\.proxmox/pull/236)\)\.
* proxmox\_disk \- change disk size units to GiB \([https\://github\.com/ansible\-collections/community\.proxmox/pull/236](https\://github\.com/ansible\-collections/community\.proxmox/pull/236)\)\.
* proxmox\_kvm \- add option to migrate local disks as well \([https\://github\.com/ansible\-collections/community\.proxmox/pull/240](https\://github\.com/ansible\-collections/community\.proxmox/pull/240)\)\.
* proxmox\_kvm \- change disk size units to GiB \([https\://github\.com/ansible\-collections/community\.proxmox/pull/236](https\://github\.com/ansible\-collections/community\.proxmox/pull/236)\)\.
* proxmox\_node\_info \- add information on node network interfaces to node information output \([https\://github\.com/ansible\-collections/community\.proxmox/pull/220](https\://github\.com/ansible\-collections/community\.proxmox/pull/220)\)\.
* proxmox\_node\_info \- add information on node\'s PVE version \([https\://github\.com/ansible\-collections/community\.proxmox/pull/225](https\://github\.com/ansible\-collections/community\.proxmox/pull/225)\)\.
* proxmox\_snap\_info \- Adds a new module to list snapshots or a specific snapshot for VM or container \([https\://github\.com/ansible\-collections/community\.proxmox/issues/229](https\://github\.com/ansible\-collections/community\.proxmox/issues/229)\)\.
* proxmox\_storage \- add feature of subdirectory in CIFS share\. \([https\://github\.com/ansible\-collections/community\.proxmox/pull/214](https\://github\.com/ansible\-collections/community\.proxmox/pull/214)\)\.
* proxmox\_storage \- fix passing nfs\_options to API payload \([https\://github\.com/ansible\-collections/community\.proxmox/issues/203](https\://github\.com/ansible\-collections/community\.proxmox/issues/203)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/221](https\://github\.com/ansible\-collections/community\.proxmox/pull/221)\)\.
* proxmox\_storage \- fixed CIFS authentication by sending username and password parameters to proxmoxer \([https\://github\.com/ansible\-collections/community\.proxmox/pull/214](https\://github\.com/ansible\-collections/community\.proxmox/pull/214)\)\.

<a id="bugfixes-2"></a>
### Bugfixes

* proxmox all \- add missing timeout parameter to proxmoxer object creation \([https\://github\.com/ansible\-collections/community\.proxmox/pull/218](https\://github\.com/ansible\-collections/community\.proxmox/pull/218)\)\.
* proxmox\_ipam\_info \- fix bug where selecting by vmid did not work \([https\://github\.com/ansible\-collections/community\.proxmox/pull/211](https\://github\.com/ansible\-collections/community\.proxmox/pull/211)\)\.
* proxmox\_zone \- fix validation logic for VXLAN zones to accept either <code>fabric</code> or <code>peers</code> parameter\. Previously\, only <code>fabric</code> was accepted\, but Proxmox VE also supports creating VXLAN zones with a peer address list \([https\://github\.com/ansible\-collections/community\.proxmox/issues/216](https\://github\.com/ansible\-collections/community\.proxmox/issues/216)\)\.
* remove wrong api endpoints and error messages from proxmod\_node certificate management\([https\://github\.com/ansible\-collections/community\.proxmox/pull/232](https\://github\.com/ansible\-collections/community\.proxmox/pull/232)\)\.

<a id="new-modules-2"></a>
### New Modules

* community\.proxmox\.proxmox\_ceph\_mds \- Add or delete Ceph Mds\.
* community\.proxmox\.proxmox\_ceph\_mgr \- Add or delete Ceph Manager\.
* community\.proxmox\.proxmox\_ceph\_mon \- Add or delete Ceph Monitor\.
* community\.proxmox\.proxmox\_sendkey \- Send key presses to a Proxmox VM console\.

<a id="v1-4-0"></a>
## v1\.4\.0

<a id="release-summary-3"></a>
### Release Summary

This is the minor release of the <code>community\.proxmox</code> collection\.
This changelog contains all changes to the modules and plugins in this collection
that have been made after the previous release\.

<a id="minor-changes-3"></a>
### Minor Changes

* proxmox \- Add delete parameter to delete settings \([https\://github\.com/ansible\-collections/community\.proxmox/pull/195](https\://github\.com/ansible\-collections/community\.proxmox/pull/195)\)\.
* proxmox\_cluster \-  Add master\_api\_password for authentication against master node \([https\://github\.com/ansible\-collections/community\.proxmox/pull/140](https\://github\.com/ansible\-collections/community\.proxmox/pull/140)\)\.
* proxmox\_cluster \- added link0 and link1 to join command \([https\://github\.com/ansible\-collections/community\.proxmox/issues/168](https\://github\.com/ansible\-collections/community\.proxmox/issues/168)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/172](https\://github\.com/ansible\-collections/community\.proxmox/pull/172)\)\.
* proxmox\_kvm \- update description of machine parameter in proxmox\_kvm\.py \([https\://github\.com/ansible\-collections/community\.proxmox/pull/186](https\://github\.com/ansible\-collections/community\.proxmox/pull/186)\)
* proxmox\_storage \- added <em class="title-reference">dir</em> and <em class="title-reference">zfspool</em> storage types \([https\://github\.com/ansible\-collections/community\.proxmox/pull/184](https\://github\.com/ansible\-collections/community\.proxmox/pull/184)\)
* proxmox\_tasks\_info \- add source option to specify tasks to consider \([https\://github\.com/ansible\-collections/community\.proxmox/pull/179](https\://github\.com/ansible\-collections/community\.proxmox/pull/179)\)
* proxmox\_template \-  Add \'import\' to allowed content types of proxmox\_template\, so disk images and can be used as disk images on VM creation \([https\://github\.com/ansible\-collections/community\.proxmox/pull/162](https\://github\.com/ansible\-collections/community\.proxmox/pull/162)\)\.

<a id="bugfixes-3"></a>
### Bugfixes

* proxmox inventory plugin and proxmox module utils \- avoid Python 2 compatibility imports \([https\://github\.com/ansible\-collections/community\.proxmox/pull/175](https\://github\.com/ansible\-collections/community\.proxmox/pull/175)\)\.
* proxmox\_kvm \- remove limited choice for vga option in proxmox\_kvm \([https\://github\.com/ansible\-collections/community\.proxmox/pull/185](https\://github\.com/ansible\-collections/community\.proxmox/pull/185)\)
* proxmox\_kvm\, proxmox\_template \- remove <code>ansible\.module\_utils\.six</code> dependency \([https\://github\.com/ansible\-collections/community\.proxmox/pull/201](https\://github\.com/ansible\-collections/community\.proxmox/pull/201)\)\.
* proxmox\_storage \- fixed adding PBS\-type storage by ensuring its parameters \(server\, datastore\, etc\.\) are correctly sent to the Proxmox API \([https\://github\.com/ansible\-collections/community\.proxmox/pull/171](https\://github\.com/ansible\-collections/community\.proxmox/pull/171)\)\.
* proxmox\_user \- added a third case when testing for not\-yet\-existant user \([https\://github\.com/ansible\-collections/community\.proxmox/issues/163](https\://github\.com/ansible\-collections/community\.proxmox/issues/163)\)
* proxmox\_vm\_info \- do not throw exception when iterating through machines and optional api results are missing \([https\://github\.com/ansible\-collections/community\.proxmox/pull/191](https\://github\.com/ansible\-collections/community\.proxmox/pull/191)\)

<a id="new-modules-3"></a>
### New Modules

* community\.proxmox\.proxmox\_cluster\_ha\_rules \- Management of HA rules\.
* community\.proxmox\.proxmox\_firewall \- Manage firewall rules in Proxmox\.
* community\.proxmox\.proxmox\_firewall\_info \- Manage firewall rules in Proxmox\.
* community\.proxmox\.proxmox\_ipam\_info \- Retrieve information about IPAMs\.
* community\.proxmox\.proxmox\_subnet \- Create/Update/Delete subnets from SDN\.
* community\.proxmox\.proxmox\_vnet \- Manage virtual networks in Proxmox SDN\.
* community\.proxmox\.proxmox\_vnet\_info \- Retrieve information about one or more Proxmox VE SDN vnets\.
* community\.proxmox\.proxmox\_zone \- Manage Proxmox zone configurations\.
* community\.proxmox\.proxmox\_zone\_info \- Get Proxmox zone info\.

<a id="v1-3-0"></a>
## v1\.3\.0

<a id="release-summary-4"></a>
### Release Summary

This is the minor release of the <code>community\.proxmox</code> collection\.
This changelog contains all changes to the modules and plugins in this collection
that have been made after the previous release\.

<a id="minor-changes-4"></a>
### Minor Changes

* proxmox\* modules \- added fallback environment variables for <code>api\_token</code>\, <code>api\_secret</code>\, and <code>validate\_certs</code> \([https\://github\.com/ansible\-collections/community\.proxmox/issues/63](https\://github\.com/ansible\-collections/community\.proxmox/issues/63)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/136](https\://github\.com/ansible\-collections/community\.proxmox/pull/136)\)\.
* proxmox\_cluster\_ha\_groups \- fix idempotency in proxmox\_cluster\_ha\_groups module \([https\://github\.com/ansible\-collections/community\.proxmox/issues/138](https\://github\.com/ansible\-collections/community\.proxmox/issues/138)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/139](https\://github\.com/ansible\-collections/community\.proxmox/pull/139)\)\.
* proxmox\_cluster\_ha\_resources \-  Fix idempotency proxmox\_cluster\_ha\_resources \([https\://github\.com/ansible\-collections/community\.proxmox/pull/135](https\://github\.com/ansible\-collections/community\.proxmox/pull/135)\)\.
* proxmox\_kvm \- Add missing \'storage\' parameter to create\_vm\(\)\-call\.
* proxmox\_kvm \- add new purge parameter to proxmox\_kvm module \([https\://github\.com/ansible\-collections/community\.proxmox/issues/60](https\://github\.com/ansible\-collections/community\.proxmox/issues/60)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/148](https\://github\.com/ansible\-collections/community\.proxmox/pull/148)\)\.

<a id="bugfixes-4"></a>
### Bugfixes

* proxmox\_pct\_remote connection plugin \- avoid deprecated ansible\-core paramiko import helper\, import paramiko directly instead \([https\://github\.com/ansible\-collections/community\.proxmox/issues/146](https\://github\.com/ansible\-collections/community\.proxmox/issues/146)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/151](https\://github\.com/ansible\-collections/community\.proxmox/pull/151)\)\.

<a id="new-modules-4"></a>
### New Modules

* community\.proxmox\.proxmox\_storage \- Manage storage in PVE clusters and nodes\.

<a id="v1-2-0"></a>
## v1\.2\.0

<a id="release-summary-5"></a>
### Release Summary

This is the minor release of the <code>community\.proxmox</code> collection\.
This changelog contains all changes to the modules and plugins in this collection that have been made after the previous release\.

<a id="minor-changes-5"></a>
### Minor Changes

* proxmox inventory plugin \- always provide basic information regardless of want\_facts \([https\://github\.com/ansible\-collections/community\.proxmox/pull/124](https\://github\.com/ansible\-collections/community\.proxmox/pull/124)\)\.
* proxmox\_cluster \- cluster creation has been made idempotent \([https\://github\.com/ansible\-collections/community\.proxmox/pull/125](https\://github\.com/ansible\-collections/community\.proxmox/pull/125)\)\.
* proxmox\_pct\_remote \- allow forward agent with paramiko \([https\://github\.com/ansible\-collections/community\.proxmox/pull/130](https\://github\.com/ansible\-collections/community\.proxmox/pull/130)\)\.

<a id="new-modules-5"></a>
### New Modules

* community\.proxmox\.proxmox\_group \- Group management for Proxmox VE cluster\.
* community\.proxmox\.proxmox\_node \- Manage Proxmox VE nodes\.
* community\.proxmox\.proxmox\_user \- User management for Proxmox VE cluster\.

<a id="v1-1-0"></a>
## v1\.1\.0

<a id="release-summary-6"></a>
### Release Summary

This is the minor release of the <code>community\.proxmox</code> collection\.
This changelog contains all changes to the modules and plugins in this collection
that have been made after the previous release\.

<a id="minor-changes-6"></a>
### Minor Changes

* proxmox \- allow force deletion of LXC containers \([https\://github\.com/ansible\-collections/community\.proxmox/pull/105](https\://github\.com/ansible\-collections/community\.proxmox/pull/105)\)\.
* proxmox \- validate the cluster name length \([https\://github\.com/ansible\-collections/community\.proxmox/pull/119](https\://github\.com/ansible\-collections/community\.proxmox/pull/119)\)\.

<a id="bugfixes-5"></a>
### Bugfixes

* proxmox inventory plugin \- avoid using deprecated option when templating options \([https\://github\.com/ansible\-collections/community\.proxmox/pull/108](https\://github\.com/ansible\-collections/community\.proxmox/pull/108)\)\.

<a id="new-modules-6"></a>
### New Modules

* community\.proxmox\.proxmox\_access\_acl \- Manages ACLs on the Proxmox PVE cluster\.
* community\.proxmox\.proxmox\_cluster\_ha\_groups \- Management of HA groups in Proxmox VE Cluster\.
* community\.proxmox\.proxmox\_cluster\_ha\_resources \- Management of HA groups in Proxmox VE Cluster\.

<a id="v1-0-1"></a>
## v1\.0\.1

<a id="release-summary-7"></a>
### Release Summary

This is a minor bugfix release for the <code>community\.proxmox</code> collections\.
This changelog contains all changes to the modules and plugins in this collection
that have been made after the previous release\.

<a id="minor-changes-7"></a>
### Minor Changes

* proxmox module utils \- fix handling warnings in LXC tasks \([https\://github\.com/ansible\-collections/community\.proxmox/pull/104](https\://github\.com/ansible\-collections/community\.proxmox/pull/104)\)\.

<a id="v1-0-0"></a>
## v1\.0\.0

<a id="release-summary-8"></a>
### Release Summary

This is the first stable release of the <code>community\.proxmox</code> collection since moving from <code>community\.general</code>\, released on 2025\-06\-08\.

<a id="minor-changes-8"></a>
### Minor Changes

* proxmox \- add support for creating and updating containers in the same task \([https\://github\.com/ansible\-collections/community\.proxmox/pull/92](https\://github\.com/ansible\-collections/community\.proxmox/pull/92)\)\.
* proxmox module util \- do not hang on tasks that throw warnings \([https\://github\.com/ansible\-collections/community\.proxmox/issues/96](https\://github\.com/ansible\-collections/community\.proxmox/issues/96)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/100](https\://github\.com/ansible\-collections/community\.proxmox/pull/100)\)\.
* proxmox\_kvm \- add <code>rng0</code> option to specify an RNG device \([https\://github\.com/ansible\-collections/community\.proxmox/pull/18](https\://github\.com/ansible\-collections/community\.proxmox/pull/18)\)\.
* proxmox\_kvm \- remove redundant check for duplicate names as this is allowed by PVE API \([https\://github\.com/ansible\-collections/community\.proxmox/issues/97](https\://github\.com/ansible\-collections/community\.proxmox/issues/97)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/99](https\://github\.com/ansible\-collections/community\.proxmox/pull/99)\)\.
* proxmox\_snap \- correctly handle proxmox\_snap timeout parameter \([https\://github\.com/ansible\-collections/community\.proxmox/issues/73](https\://github\.com/ansible\-collections/community\.proxmox/issues/73)\, [https\://github\.com/ansible\-collections/community\.proxmox/issues/95](https\://github\.com/ansible\-collections/community\.proxmox/issues/95)\, [https\://github\.com/ansible\-collections/community\.proxmox/pull/101](https\://github\.com/ansible\-collections/community\.proxmox/pull/101)\)\.

<a id="breaking-changes--porting-guide-1"></a>
### Breaking Changes / Porting Guide

* proxmox \- <code>update</code> and <code>force</code> are now mutually exclusive \([https\://github\.com/ansible\-collections/community\.proxmox/pull/92](https\://github\.com/ansible\-collections/community\.proxmox/pull/92)\)\.
* proxmox \- the default of <code>update</code> changed from <code>false</code> to <code>true</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/92](https\://github\.com/ansible\-collections/community\.proxmox/pull/92)\)\.

<a id="bugfixes-6"></a>
### Bugfixes

* proxmox \- fix crash in module when the used on an existing LXC container with <code>state\=present</code> and <code>force\=true</code> \([https\://github\.com/ansible\-collections/community\.proxmox/pull/91](https\://github\.com/ansible\-collections/community\.proxmox/pull/91)\)\.

<a id="new-modules-7"></a>
### New Modules

* community\.proxmox\.proxmox\_backup\_schedule \- Schedule VM backups and removing them\.
* community\.proxmox\.proxmox\_cluster \- Create and join Proxmox VE clusters\.
* community\.proxmox\.proxmox\_cluster\_join\_info \- Retrieve the join information of the Proxmox VE cluster\.

<a id="v0-1-0"></a>
## v0\.1\.0

<a id="release-summary-9"></a>
### Release Summary

This is the first community\.proxmox release\. It contains mainly the state of the Proxmox content in community\.general 10\.6\.0\.
The minimum required ansible\-core version for community\.proxmox is ansible\-core 2\.17\, which implies Python 3\.7\+\.
The minimum required proxmoxer version is 2\.0\.0\.
