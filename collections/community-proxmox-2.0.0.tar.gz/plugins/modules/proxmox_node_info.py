#!/usr/bin/python
#
# Copyright John Berninger (@jberning) <john.berninger at gmail.com>
# GNU General Public License v3.0+ (see LICENSES/GPL-3.0-or-later.txt or https://www.gnu.org/licenses/gpl-3.0.txt)
# SPDX-License-Identifier: GPL-3.0-or-later


DOCUMENTATION = r"""
module: proxmox_node_info
short_description: Retrieve information about one or more Proxmox VE nodes
description:
  - Retrieve information about one or more Proxmox VE nodes.
author: John Berninger (@jwbernin)
extends_documentation_fragment:
  - community.proxmox.proxmox.actiongroup_proxmox
  - community.proxmox.proxmox.documentation
  - community.proxmox.attributes
  - community.proxmox.attributes.info_module
"""


EXAMPLES = r"""
- name: List existing nodes
  community.proxmox.proxmox_node_info:
  register: proxmox_nodes
"""


RETURN = r"""
proxmox_nodes:
  description: List of Proxmox VE nodes.
  returned: always, but can be empty
  type: list
  elements: dict
  contains:
    cpu:
      description: Current CPU usage in fractional shares of this host's total available CPU.
      returned: on success
      type: float
    disk:
      description: Current local disk usage of this host.
      returned: on success
      type: int
    id:
      description: Identity of the node.
      returned: on success
      type: str
    level:
      description: Support level. Can be blank if not under a paid support contract.
      returned: on success
      type: str
    maxcpu:
      description: Total number of available CPUs on this host.
      returned: on success
      type: int
    maxdisk:
      description: Size of local disk in bytes.
      returned: on success
      type: int
    maxmem:
      description: Memory size in bytes.
      returned: on success
      type: int
    mem:
      description: Used memory in bytes.
      returned: on success
      type: int
    network:
      description: Active network interfaces on the node
      returned: on success
      type: dict
    node:
      description: Short hostname of this node.
      returned: on success
      type: str
    ssl_fingerprint:
      description: SSL fingerprint of the node certificate.
      returned: on success
      type: str
    status:
      description: Node status.
      returned: on success
      type: str
    type:
      description: Object type being returned.
      returned: on success
      type: str
    uptime:
      description: Node uptime in seconds.
      returned: on success
      type: int
    version:
      description: Version of PVE on the node
      returned: on success
      type: dict
"""


from ansible_collections.community.proxmox.plugins.module_utils.proxmox import (
    ProxmoxAnsible,
    create_proxmox_module,
)


def module_args():
    return dict()


def module_options():
    return {}


class ProxmoxNodeInfoAnsible(ProxmoxAnsible):
    def get_nodes(self):
        nodes = self.proxmox_api.nodes.get()
        for node in nodes:
            node_name = node["node"]
            ifaces = self.proxmox_api.nodes(node_name).network.get()
            node["network"] = ifaces
            node["version"] = self.proxmox_api.nodes(node_name).version.get()
        return nodes


def main():
    module = create_proxmox_module(module_args(), **module_options())
    proxmox = ProxmoxNodeInfoAnsible(module)

    result = dict(changed=False)

    nodes = proxmox.get_nodes()
    result["proxmox_nodes"] = nodes

    module.exit_json(**result)


if __name__ == "__main__":
    main()
